# GitHub feltöltés a PC-ről

1. Csomagold ki `Elizabeth-AI-Fusion-Android-AI-SOURCE.zip` fájlt.
2. Lépj a `https://github.com/Lack0o/Elizabeth-AI-Fusion/upload/main` oldalra.
3. A **kicsomagolt gyökérben** lévő elemeket töltsd fel, többek között:
   `app/`, `docs/`, `.github/workflows/android-apk.yml`, `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `.gitignore`, `README.md`.
4. A `.github` rejtett mappa feltöltése böngészőből néha nehéz; telepített Git esetén:
   ```bat
   git clone https://github.com/Lack0o/Elizabeth-AI-Fusion.git
   cd Elizabeth-AI-Fusion
   rem Másold be a forrásprojekt tartalmát a repó gyökerébe.
   git add .
   git commit -m "Implement Elizabeth Android local AI in Kotlin"
   git push origin main
   ```
5. GitHub Actions oldalon ellenőrizd a `Elizabeth Android AI APK` nevű futtatást. A sikeres build artifactje az APK.

**Biztonság:** a repo a legutóbbi ellenőrzéskor nyilvános volt; tulajdonosi titkokat, PIN-kódot, modelllicenccel korlátozott fájlokat vagy személyes adatot ne tölts fel.
