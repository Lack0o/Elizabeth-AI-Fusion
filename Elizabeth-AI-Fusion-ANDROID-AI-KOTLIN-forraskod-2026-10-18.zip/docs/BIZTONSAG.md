# Biztonsági modell

1. **Tulajdonosi ellenőrzés**: PIN minimum 6 karakter, sózott PBKDF2-HMAC-SHA256 180 000 iteráció, állandó idejű összehasonlítás.
2. **Helyi titkosítás**: AES-256-GCM kulcs Android Keystore-ban; a PIN-verifikátor a SharedPreferences-ben található. Az alkalmazás saját adatai nem férhetők hozzá normál másik alkalmazásból.
3. **Hordozható backup**: külön sózott PIN-eredetű AES-GCM állomány. A másik telefonon való visszaállításhoz ugyanaz a PIN szükséges, és új appbeállítást előbb ezzel a PIN-nel kell létrehozni.
4. **Nincs INTERNET engedély**: semmilyen beépített online végrehajtás. A modellfájlt a tulajdonos választja ki az Android SAF rendszerén keresztül.
5. **Műveleti mátrix**: nem implementált hálózati, pénzügyi, jogosultsági vagy alkalmazás-önmódosító műveleteket a modell nem indíthat el.
6. **Leállítás**: PIN-kéréssel leállítja a helyi appot, újranyitáskor PIN szükséges. Ez nem vonatkozik távoli szerverekre, n8n folyamatokra vagy más eszközökön futó programokra.
7. **Megmaradó kockázatok**: nincs PIN próbálkozási limit; PIN-kód nem azonos Android biometrikus biztonsággal; Android kernel/root támadástól nem véd; logok korlátozottak; túl nagy helyi modell eszközfüggő memóriagondot okozhat. Végleges változatban audit, rate limiting, release signing, instrumentációs teszt szükséges.
