# Következő fejlesztési szakaszok, nem jelenlegi funkciók

1. Android instrumentációs és memóriahasználati tesztek több valós telefonon.
2. Teljes lokális modellegységek (GPU/NPU választás eszközvizsgálattal, intelligens hőmérséklet-, energia- és memóriakorlátok).
3. SQLite + Full Text Search + opcionális lokális embedding, a jelenlegi egyszerű tokenmemória helyett.
4. Érvelési készségek fejlesztése: ellenőrzött számítás, forrásértékelés, szerkesztett programkód helyi statikus vizsgálata, kódtesztek külön izolált környezetben.
5. Visszacsatolás: mért feladatpontosság, kalibrált önbizalom-becslés, hibajelzés; a Beta posterior nem az igazság valószínűsége.
6. Helyi, tulajdonos által jóváhagyott feladatsorok, visszavonhatóság és auditálható végrehajtás; nem automatikus, korlátlan külső hozzáférés.
7. Biometrikus feloldás és sikertelen PIN próbálkozások késleltetése.
8. Export/import integritás és migráció, titkosított fájlon belüli schema versioning.
9. Offline beszéd- és képmodellek, csak eszközszintű támogatás és explicit engedély után.
10. Reprodukálható GitHub CI, aláírt release, eszköztanúsítványok ellenőrzése.
