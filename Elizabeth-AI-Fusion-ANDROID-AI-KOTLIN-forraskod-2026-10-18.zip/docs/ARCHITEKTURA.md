# Elizabeth AI Fusion – belső működés

```
Android natív felület / tulajdonosi PIN
       │
       ▼
Tulajdonosi műveleti szabályok → fontos akció: manuális PIN
       │
       ├── Offline adatok ──→ Android Keystore AES-GCM
       │                         ├── beszélgetések
       │                         ├── személyes memória
       │                         ├── teendők
       │                         └── audit napló
       │
       ▼
AI kérések → releváns memória kiválasztás → identitás/promptsablon
       │
       ├── neural modell nincs → egyértelmű fallback, számológép
       │
       └── kompatibilis .litertlm modell van
                   │
           LiteRT-LM 0.18.0 natív motor, CPU
                   │
           általános / fejlesztő / elemző
                   │
           opcionális „tanácskozás”
             ├── 1. tervező következtetés
             ├── 2. kritikus felülvizsgálat
             └── 3. konszolidált válasz
                   │
                 UI válasz
                   │
             👍 vagy 👎 → emlék-rangsorolás/értékelési napló
```

## Valószínűségi értékelés

Az értékelés Beta posteriora `(jó+1)/(jó+rossz+2)`; ez explicit visszajelzésekből képzett **szubjektív hasznossági jelző**. Nem tudja bizonyítani az AI válasz helyességét, és nem változtat a neurális háló súlyain. Az egyszerű token-alapú relevanciakeresés és visszajelzések kombinációja biztosít változó kontextust.

## Döntések

A `OwnerPolicy` explicit, auditálható mátrixot tartalmaz. Az `EXTERNAL_SEND`, `FINANCIAL`, `PERMISSIONS`, `SELF_UPDATE` tiltott/nem implementált; a modell soha nem kap végrehajtási eszközt. A későbbi verzióknál éles végrehajtó integráció csak műveleti naplóval, tulajdonosi előzetes engedéllyel, legkisebb hozzáféréssel és hitelesíthető visszavonással adható hozzá.

## Fenntarthatóság

- Az AI a hívás alatt fut egyetlen worker szálon, nem próbál önálló újraindulást.
- A `COUNCIL` mód három modelligényes lépés, nem három külön idegen modell.
- Egyetlen helyi `.litertlm` modellt tud használni. Az eltávolításához jelenleg app-adatkezelés vagy új modell import kell.
- A `state` 8 MB limitű JSON struktúra; ne használjuk nagy tudásbázis tárolására. A tároló későbbi SQLite/WAL migrációt igényel.
