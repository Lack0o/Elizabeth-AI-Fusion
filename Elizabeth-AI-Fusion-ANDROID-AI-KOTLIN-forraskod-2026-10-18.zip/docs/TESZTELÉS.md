# Kötelező tesztlista végleges kiadás előtt

## Automatikus (a pure Kotlin tesztekhez Android SDK is kell a JUnit futtatáshoz)
- `gradle :app:testDebugUnitTest`
- `gradle :app:assembleDebug`
- ZIP struktúra: AndroidManifest, settings.gradle.kts, app, workflow.

## Fizikai Android telefonon
1. Első futtatás / tulajdonosi PIN létrehozás, helytelen PIN elutasítása.
2. Bezárás és visszanyitás → PIN feloldás, előzmények titkosított megőrzése.
3. Emlék felvitele, releváns kérdések, pozitív/negatív visszajelzés, memória törlés hitelesítéssel.
4. Feladatok felvitele/pipálás/törlés.
5. Modell nélkül fallback egyértelmű, `= (2+3)*4` eredménye 20.
6. Hivatalos LiteRT-LM-kompatibilis modell importálása, telefonon való generálás repülőgép üzemmódban.
7. FEJLESZTŐ/ANALITIKUS/TANÁCSKOZÓ mód konzisztenciája, memóriahasználat és várakozás.
8. `.eab` export→új állapot→import→tartalom egyezik, hibás PIN és sérült backup elutasítva.
9. PIN-es leállítás: nincs futó app, újraindításkor zárolt.
10. Teljes adatforgalom figyelés: semmilyen beépített hálózati kapcsolódás.
11. Felszabaduló tárhely, hibás vagy túl nagy modellfájl és alacsony memória megfelelő hibaüzenettel.
12. Forgatás, háttérbe helyezés, processz halál és újraindítás utáni állapotváltozások.

## Jelenlegi validáció
- A tiszta Kotlin számoló és policy kódot helyi Kotlin CLI-vel futtatjuk.
- Android APK / JNI / valódi neurális modell: **nem ellenőrzött**.
