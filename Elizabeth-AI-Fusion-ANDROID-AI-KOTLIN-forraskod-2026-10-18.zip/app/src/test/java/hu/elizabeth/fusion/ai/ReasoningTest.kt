package hu.elizabeth.fusion.ai

import org.junit.Assert.*
import org.junit.Test

class ReasoningTest {
    @Test fun priorsAndFeedback() {
        assertEquals(0.5, Confidence.feedbackPosterior(0, 0), 1e-9)
        assertTrue(Confidence.feedbackPosterior(4, 1) > Confidence.feedbackPosterior(1, 4))
    }
    @Test fun relevance() {
        assertTrue(Confidence.memoryScore("kedvenc könyvek", "kedvenc könyvek", 1, 0) >
            Confidence.memoryScore("kedvenc könyvek", "autó gumiabroncs", 1, 0))
    }
    @Test fun policy() {
        assertTrue(OwnerPolicy.ownerPinRequired(Operation.OWNER_SHUTDOWN))
        assertFalse(OwnerPolicy.actuallyImplemented(Operation.EXTERNAL_SEND))
        assertFalse(OwnerPolicy.ownerPinRequired(Operation.LOCAL_READ))
    }
    @Test fun calculator() {
        assertEquals(14.0, Calculator("2+3*4").calculate(), 1e-9)
        assertEquals(25.0, Calculator("(2+3)^2").calculate(), 1e-9)
        assertEquals(0.2, Calculator("20%").calculate(), 1e-9)
    }
    @Test(expected = IllegalArgumentException::class) fun noShell() { Calculator("1; rm -rf /").calculate() }
}
