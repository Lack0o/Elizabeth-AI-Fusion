package hu.elizabeth.fusion.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ChatTurn(
    val id: String = UUID.randomUUID().toString(),
    val role: String,
    val text: String,
    val epoch: Long = System.currentTimeMillis(),
    var feedback: Int = 0 // -1 / 0 / +1
)

data class Knowledge(
    val id: String = UUID.randomUUID().toString(),
    var text: String,
    val source: String = "Tulajdonos által rögzített adat",
    val created: Long = System.currentTimeMillis(),
    var good: Int = 0,
    var bad: Int = 0
)

data class Todo(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    var done: Boolean = false,
    val created: Long = System.currentTimeMillis()
)

/** Serializes only user-owned data; no API tokens, model weights, device IDs or secrets. */
class ElizabethState {
    var displayName: String = "Nagy Noémi Elizabeth"
    var ownerPreferredLanguage: String = "magyar"
    var modelName: String = ""
    var aiMode: String = "GENERAL"
    val history: MutableList<ChatTurn> = mutableListOf()
    val memories: MutableList<Knowledge> = mutableListOf()
    val tasks: MutableList<Todo> = mutableListOf()
    val audit: MutableList<String> = mutableListOf()

    fun log(text: String) {
        audit.add("${System.currentTimeMillis()} | ${text.take(150)}")
        while (audit.size > 250) audit.removeAt(0)
    }

    fun toJson(): String {
        val obj = JSONObject()
        obj.put("schema", 1)
        obj.put("displayName", displayName)
        obj.put("ownerPreferredLanguage", ownerPreferredLanguage)
        obj.put("modelName", modelName)
        obj.put("aiMode", aiMode)
        val h = JSONArray()
        history.forEach {
            h.put(JSONObject().put("id",it.id).put("role",it.role).put("text",it.text)
                .put("epoch",it.epoch).put("feedback",it.feedback))
        }
        obj.put("history",h)
        val m = JSONArray()
        memories.forEach {
            m.put(JSONObject().put("id",it.id).put("text",it.text).put("source",it.source)
                .put("created",it.created).put("good",it.good).put("bad",it.bad))
        }
        obj.put("memories",m)
        val t = JSONArray()
        tasks.forEach {
            t.put(JSONObject().put("id",it.id).put("title",it.title)
                .put("done",it.done).put("created",it.created))
        }
        obj.put("tasks",t)
        obj.put("audit",JSONArray(audit))
        return obj.toString()
    }

    companion object {
        fun fromJson(content: String): ElizabethState {
            require(content.length <= 8_000_000) { "Túl nagy adatállomány" }
            val obj = JSONObject(content)
            require(obj.getInt("schema") == 1) { "Nem támogatott adatverzió" }
            val s = ElizabethState()
            s.displayName = obj.optString("displayName", s.displayName).take(100)
            s.ownerPreferredLanguage = obj.optString("ownerPreferredLanguage", "magyar").take(30)
            s.modelName = obj.optString("modelName", "").take(150)
            s.aiMode = obj.optString("aiMode", "GENERAL").takeIf { it in listOf("GENERAL","DEVELOPER","ANALYST","COUNCIL") } ?: "GENERAL"
            val h = obj.optJSONArray("history") ?: JSONArray()
            for(i in 0 until minOf(h.length(), 500)) {
                val v = h.optJSONObject(i) ?: continue
                val role = v.optString("role")
                if (role !in listOf("user", "assistant")) continue
                s.history.add(ChatTurn(
                    v.optString("id", UUID.randomUUID().toString()), role,
                    v.optString("text").take(5000), v.optLong("epoch"),
                    v.optInt("feedback").coerceIn(-1,1)))
            }
            val m = obj.optJSONArray("memories") ?: JSONArray()
            for (i in 0 until minOf(m.length(), 500)) {
                val v = m.optJSONObject(i) ?: continue
                s.memories.add(Knowledge(
                    v.optString("id",UUID.randomUUID().toString()),
                    v.optString("text").take(3000), v.optString("source").take(150),
                    v.optLong("created"),v.optInt("good").coerceIn(0,10000),
                    v.optInt("bad").coerceIn(0,10000)))
            }
            val t = obj.optJSONArray("tasks") ?: JSONArray()
            for (i in 0 until minOf(t.length(), 500)) {
                val v = t.optJSONObject(i) ?: continue
                s.tasks.add(Todo(v.optString("id",UUID.randomUUID().toString()),
                    v.optString("title").take(1000),v.optBoolean("done"),v.optLong("created")))
            }
            val a = obj.optJSONArray("audit") ?: JSONArray()
            for (i in 0 until minOf(a.length(),250)) s.audit.add(a.optString(i).take(300))
            return s
        }
    }
}
