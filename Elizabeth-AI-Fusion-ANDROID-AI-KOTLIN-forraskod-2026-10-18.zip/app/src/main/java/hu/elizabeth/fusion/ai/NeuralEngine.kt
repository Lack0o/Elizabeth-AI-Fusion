package hu.elizabeth.fusion.ai

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import hu.elizabeth.fusion.data.ElizabethState
import java.io.File

/** Actual offline neural inference; no hosted API calls, no network permissions. */
class NeuralEngine {
    private var engine: Engine? = null
    private var loadedPath: String? = null
    private val planner = OfflineBrain()

    /** Call only on serial background executor, never on the Android UI thread. */
    fun answer(model: File, user: String, state: ElizabethState, extraGuidance: String = ""): String {
        require(model.isFile && model.name.endsWith(".litertlm") && model.length() > 1024)
        if (loadedPath != model.absolutePath || engine == null) {
            close()
            val fresh = Engine(EngineConfig(modelPath = model.absolutePath,
                backend = Backend.CPU(), cacheDir = model.parentFile!!.absolutePath))
            try { fresh.initialize() } catch (t: Throwable) { fresh.close(); throw t }
            engine = fresh
            loadedPath = model.absolutePath
        }
        val context = planner.systemContext(user,state) + "\nMódutasítás: " + extraGuidance.take(900)
        val conversation = engine!!.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(context),
                samplerConfig = SamplerConfig(topK=20, topP=0.9, temperature=0.6)
            )
        )
        return conversation.use {
            // Automatic tool calling is not configured: no model-triggered file or device writes.
            it.sendMessage(user).toString().trim()
        }
    }

    fun close() { engine?.close(); engine = null; loadedPath = null }
}
