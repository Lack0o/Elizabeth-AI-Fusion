package hu.elizabeth.fusion.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import hu.elizabeth.fusion.data.ElizabethState
import org.json.JSONObject
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

private fun ByteArray.enc(): String = Base64.encodeToString(this, Base64.NO_WRAP)
private fun String.dec(): ByteArray = Base64.decode(this, Base64.NO_WRAP)

/** Device-keystore encrypted records, PIN verified before entering the app. */
class SecureStorage(context: Context) {
    private val prefs = context.getSharedPreferences("elizabeth_security_v1", Context.MODE_PRIVATE)
    private val alias = "elizabeth_local_aes_v1"

    val configured: Boolean get() = prefs.contains("pinVerifier")
    val halted: Boolean get() = prefs.getBoolean("halted", false)

    fun setPinOnce(pin: String) {
        require(!configured && pin.length >= 6 && pin.length <= 100)
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val digest = pinHash(pin,salt)
        check(prefs.edit().putString("salt",salt.enc())
            .putString("pinVerifier",digest.enc()).putBoolean("halted",false).commit())
    }

    fun verifyPin(pin: String): Boolean {
        if (!configured) return false
        val salt = prefs.getString("salt",null)?.dec() ?: return false
        val expected = prefs.getString("pinVerifier",null)?.dec() ?: return false
        return try { MessageDigest.isEqual(expected,pinHash(pin,salt)) } catch (_: Exception) { false }
    }

    fun setHalted(stop: Boolean) { check(prefs.edit().putBoolean("halted",stop).commit()) }

    private fun pinHash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(),salt,180_000,256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun keystoreKey(): SecretKey {
        val keystore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val old = keystore.getKey(alias, null) as? SecretKey
        if (old != null) return old
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return gen.generateKey()
    }

    fun save(state: ElizabethState) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE,keystoreKey())
        val bytes = cipher.doFinal(state.toJson().toByteArray(Charsets.UTF_8))
        check(prefs.edit().putString("state", JSONObject()
            .put("iv",cipher.iv.enc()).put("ct",bytes.enc()).toString()).commit())
    }

    fun load(): ElizabethState {
        val raw = prefs.getString("state",null) ?: return ElizabethState()
        val obj = JSONObject(raw)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,keystoreKey(),GCMParameterSpec(128,obj.getString("iv").dec()))
        val bytes = cipher.doFinal(obj.getString("ct").dec())
        return ElizabethState.fromJson(String(bytes,Charsets.UTF_8))
    }

    /** Portable owner-PIN AES-GCM backup. The model file is intentionally not exported. */
    fun encryptedBackup(state: ElizabethState, pin: String): String {
        require(verifyPin(pin))
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val key = SecretKeySpec(pinHash(pin,salt),"AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE,key)
        val data = cipher.doFinal(state.toJson().toByteArray(Charsets.UTF_8))
        return JSONObject().put("format","ElizabethEncryptedBackupV1")
            .put("salt",salt.enc()).put("iv",cipher.iv.enc())
            .put("ct",data.enc()).toString()
    }

    fun readBackup(input: String, pin: String): ElizabethState {
        require(verifyPin(pin)) { "Tulajdonosi PIN nem megfelelő" }
        require(input.length < 12_000_000)
        val obj = JSONObject(input)
        require(obj.getString("format") == "ElizabethEncryptedBackupV1")
        val key = SecretKeySpec(pinHash(pin,obj.getString("salt").dec()),"AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,key,GCMParameterSpec(128,obj.getString("iv").dec()))
        val plain = cipher.doFinal(obj.getString("ct").dec())
        return ElizabethState.fromJson(String(plain,Charsets.UTF_8))
    }
}
