package hu.elizabeth.fusion.ai

import hu.elizabeth.fusion.data.ElizabethState
import java.io.File

/** Optional sequential role-based review using one on-device language model. */
class Council(private val engine: NeuralEngine) {
    fun generate(model: File, message: String, state: ElizabethState): String {
        return when(state.aiMode) {
            "DEVELOPER" -> engine.answer(model,message,state,
                "Szoftverfejlesztő mód: adj olvasható működő kódot, ellenőrizhető tesztet, hibakezelést; jelezd a nem tesztelt részeket.")
            "ANALYST" -> engine.answer(model,message,state,
                "Analitikus mód: különítsd el a tényt, feltételezést, bizonytalanságot, alternatívákat és ellenőrzési módot.")
            "COUNCIL" -> {
                // Explicitly user-selected: higher latency and resource usage.
                val plan=engine.answer(model,"Készíts tömör lépésekből álló megoldási tervet erre: $message",state,
                    "TERVEZŐ szerep. Ne végezz műveletet, csak javasolj végrehajtható tervet.").take(3200)
                val critique=engine.answer(model,"Vizsgáld kritikusan a tervet az eredeti kéréshez mérve. Kérés: $message\nTerv: $plan",state,
                    "ELLENŐR szerep. Keress logikai hibákat, hiányzó bizonyítékot és kockázatot; ne állíts találgatást tényként.").take(3200)
                engine.answer(model,"Kérés: $message\nTerv: $plan\nKritikus felülvizsgálat: $critique\nAdj végső, végrehajtható választ és jelezd, mi bizonytalan.",state,
                    "SZINTETIZÁLÓ szerep. A kritikát építsd be, ne találj ki végrehajtott műveleteket.")
            }
            else -> engine.answer(model,message,state)
        }
    }
}
