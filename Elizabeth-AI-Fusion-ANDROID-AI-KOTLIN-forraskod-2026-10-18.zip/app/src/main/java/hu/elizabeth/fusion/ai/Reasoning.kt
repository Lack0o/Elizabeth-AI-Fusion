package hu.elizabeth.fusion.ai

import java.util.Locale
import kotlin.math.max

/** Deterministic, auditable decisions; NOT a model's self-reported probability. */
object Confidence {
    fun feedbackPosterior(good: Int, bad: Int): Double {
        require(good >= 0 && bad >= 0)
        return (good + 1.0) / (good + bad + 2.0) // Beta(1,1) prior
    }

    /** A simple ranking heuristic, not a calibrated factual probability. */
    fun memoryScore(query: String, memory: String, good: Int, bad: Int): Double {
        val q = tokens(query)
        val m = tokens(memory)
        if (q.isEmpty() || m.isEmpty()) return 0.0
        val coverage = q.intersect(m).size.toDouble() / q.size
        return coverage * (0.5 + 0.5 * feedbackPosterior(good, bad))
    }

    fun tokens(text: String): Set<String> = text.lowercase(Locale.ROOT)
        .split(Regex("[^\\p{L}\\p{N}]+"))
        .filter { it.length > 2 }
        .toSet()
}

enum class Operation { LOCAL_READ, LOCAL_WRITE, EXPORT, IMPORT, DELETE, EXTERNAL_SEND, FINANCIAL, PERMISSIONS, SELF_UPDATE, OWNER_SHUTDOWN }

/** Riskier actions never run just because language model text requested them. */
object OwnerPolicy {
    fun ownerPinRequired(op: Operation): Boolean = when (op) {
        Operation.LOCAL_READ, Operation.LOCAL_WRITE -> false
        Operation.EXPORT, Operation.IMPORT, Operation.DELETE, Operation.EXTERNAL_SEND,
        Operation.FINANCIAL, Operation.PERMISSIONS, Operation.SELF_UPDATE,
        Operation.OWNER_SHUTDOWN -> true
    }
    fun actuallyImplemented(op: Operation): Boolean = when (op) {
        Operation.LOCAL_READ, Operation.LOCAL_WRITE, Operation.EXPORT,
        Operation.IMPORT, Operation.DELETE, Operation.OWNER_SHUTDOWN -> true
        else -> false
    }
}

/** Safe arithmetic grammar (no eval, reflection or shell execution). */
class Calculator(private val input: String) {
    private var index = 0
    fun calculate(): Double {
        require(input.length in 1..200 && input.all { it in "0123456789.,+-*/()^% \t" })
        val value = sum()
        spaces()
        require(index == input.length && value.isFinite()) { "Érvénytelen képlet" }
        return value
    }
    private fun spaces() { while (index < input.length && input[index].isWhitespace()) index++ }
    private fun take(c: Char): Boolean { spaces(); if (index < input.length && input[index] == c) { index++; return true }; return false }
    private fun sum(): Double {
        var value = product()
        while (true) value = when {
            take('+') -> value + product()
            take('-') -> value - product()
            else -> return value
        }
    }
    private fun product(): Double {
        var value = exponent()
        while (true) value = when {
            take('*') -> value * exponent()
            take('/') -> value / exponent()
            else -> return value
        }
    }
    private fun exponent(): Double {
        var v = atom()
        if (take('^')) v = Math.pow(v, exponent())
        return v
    }
    private fun atom(): Double {
        spaces()
        if (take('+')) return atom()
        if (take('-')) return -atom()
        if (take('(')) {
            val inner = sum()
            require(take(')'))
            return inner
        }
        val start = index
        while (index < input.length && (input[index].isDigit() || input[index] == '.' || input[index] == ',')) index++
        require(start != index)
        val n = input.substring(start, index).replace(',', '.').toDouble()
        return if (take('%')) n / 100 else n
    }
}
