package hu.elizabeth.fusion.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.Spinner
import android.widget.ArrayAdapter
import hu.elizabeth.fusion.ai.*
import hu.elizabeth.fusion.data.*
import hu.elizabeth.fusion.security.SecureStorage
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** A standalone Android-only app: zero network, local on-device model only. */
class MainActivity : Activity() {
    private companion object {
        const val PICK_MODEL = 101
        const val EXPORT_BACKUP = 102
        const val IMPORT_BACKUP = 103
        const val BG = 0xff111923.toInt()
        const val CARD = 0xff25364b.toInt()
        const val TEXT = 0xfff2f7ff.toInt()
        const val SUB = 0xffb9c9dc.toInt()
        const val HIGHLIGHT = 0xff98dcff.toInt()
    }

    private lateinit var secure: SecureStorage
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private var data = ElizabethState()
    private val worker = Executors.newSingleThreadExecutor()
    private val neural = NeuralEngine()
    private val rules = OfflineBrain()
    private val council = Council(neural)
    private val stopped = AtomicBoolean(false)
    private var busy = false
    private var unlocked = false
    private var lastBackgroundAt: Long = 0
    private var currentTab = "chat"
    private var exportPin = ""
    private var importPin = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        secure = SecureStorage(this)
        root = column().apply { setBackgroundColor(BG); setPadding(dp(14),dp(15),dp(14),dp(6)) }
        setContentView(root)
        if (!secure.configured) showPinCreation() else showUnlock()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun title(text: String, sp: Float = 16f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0,dp(6),0,dp(6))
        }

    private fun space(parent: LinearLayout, size: Int = 12) {
        parent.addView(View(this), LinearLayout.LayoutParams(dp(1),dp(size)))
    }

    private fun edit(parent: LinearLayout, hint: String, multiline: Boolean = false, secret: Boolean = false): EditText {
        val input = EditText(this).apply {
            setSingleLine(!multiline)
            this.hint = hint
            textSize = 16f
            setTextColor(TEXT)
            setHintTextColor(SUB)
            setBackgroundColor(CARD)
            setPadding(dp(12),dp(13),dp(12),dp(13))
            if (multiline) minLines = 3
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        parent.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
        return input
    }

    private fun action(parent: LinearLayout, caption: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = caption
            setAllCaps(false)
            textSize = 13f
            parent.addView(this, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = dp(6) })
            setOnClickListener { onClick() }
        }

    private fun topScreen(mainTitle: String, subtitle: String) {
        root.removeAllViews()
        root.addView(title(mainTitle,23f,TEXT,true))
        root.addView(title(subtitle,12f,SUB))
        space(root)
    }

    private fun scrollPanel(): LinearLayout {
        val scroll = ScrollView(this)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val body = column().apply { setPadding(0,dp(8),0,dp(30)) }
        scroll.addView(body)
        return body
    }

    private fun showPinCreation() {
        topScreen("Nagy Noémi Elizabeth", "Első indítás • Tulajdonosi védelem")
        val body = scrollPanel()
        body.addView(title("Adj meg legalább 6 karakterből álló PIN-t vagy jelszót.",15f))
        body.addView(title("A PIN elfelejtése esetén nincs hátsó hozzáférés. Elveszett PIN-nel a mentések sem állíthatók vissza.",13f,SUB))
        val pin = edit(body,"Tulajdonosi PIN / jelszó",secret=true)
        val again = edit(body,"PIN / jelszó ismét",secret=true)
        action(body,"Biztonságos helyi rendszer létrehozása") {
            val p = pin.text.toString()
            if (p.length < 6 || p != again.text.toString()) {
                info("A PIN legalább 6 karakter és a két mezőnek egyeznie kell."); return@action
            }
            try {
                secure.setPinOnce(p)
                data = ElizabethState()
                data.log("Tulajdonosi zár létrehozva")
                secure.save(data)
                unlocked = true
                showApp("chat")
            } catch (e: Exception) { info("Beállítási hiba: ${e.message}") }
        }
    }

    private fun showUnlock() {
        topScreen("Nagy Noémi Elizabeth", if (secure.halted) "A rendszer tulajdonosi kérésre leállítva" else "Tulajdonosi feloldás")
        val body = scrollPanel()
        val pin = edit(body,"PIN / jelszó",secret=true)
        action(body,"Feloldás") {
            if (!secure.verifyPin(pin.text.toString())) { info("Hibás PIN."); return@action }
            try {
                data = secure.load() // Never silently reset a corrupted encrypted state.
                stopped.set(false)
                secure.setHalted(false)
                unlocked = true
                data.log("Tulajdonos feloldotta az alkalmazást")
                secure.save(data)
                unlocked = true
                showApp("chat")
            } catch (e: Exception) {
                AlertDialog.Builder(this).setTitle("Titkosított adat nem nyitható")
                    .setMessage("A helyi adatok sérültek vagy az Android Keystore kulcs nem érhető el. Adatot nem töröltem. ${e.message}")
                    .setPositiveButton("Rendben",null).show()
            }
        }
    }

    private fun showApp(tab: String) {
        if (stopped.get()) return
        currentTab = tab
        topScreen(data.displayName, "Offline Android AI • v1.0 alpha")
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        root.addView(nav)
        fun navbar(text: String,id: String) {
            val b=Button(this).apply {
                this.text=text
                setAllCaps(false)
                textSize=10f
                setPadding(0,0,0,0)
            }
            nav.addView(b,LinearLayout.LayoutParams(0,dp(49),1f))
            b.setOnClickListener { showApp(id) }
        }
        navbar("AI","chat")
        navbar("Memória","memory")
        navbar("Teendők","tasks")
        navbar("Tulajdonos","owner")
        panel = scrollPanel()
        when (tab) {
            "chat" -> showChat()
            "memory" -> showMemory()
            "tasks" -> showTasks()
            else -> showOwner()
        }
    }

    private fun save() {
        if (!stopped.get()) secure.save(data)
    }

    private fun modelFile(): File = File(filesDir,"models/owner_model.litertlm")

    private fun showChat() {
        val installed = modelFile().isFile
        panel.addView(title(if (installed) "Neurális modell: telepítve (offline)" else "Neurális modell: még nincs importálva",14f, if(installed) HIGHLIGHT else SUB,true))
        panel.addView(title("Saját telefonos modell • Titkosított beszélgetési előzmény • Visszajelzés",12f,SUB))
        panel.addView(title("Aktív AI mód: ${data.aiMode}",12f,HIGHLIGHT))
        space(panel)
        for (turn in data.history.takeLast(12)) {
            val card = column().apply {
                setPadding(dp(12),dp(9),dp(12),dp(11))
                setBackgroundColor(CARD)
            }
            val caption = if (turn.role == "user") "Te" else "Elizabeth"
            card.addView(title(caption,12f,HIGHLIGHT,true))
            val body = title(turn.text,14f)
            body.setTextIsSelectable(true)
            card.addView(body)
            if (turn.role == "assistant") {
                val feedbackBar = LinearLayout(this)
                card.addView(feedbackBar)
                val good = Button(this).apply { text="👍"; textSize=15f }
                val bad  = Button(this).apply { text="👎"; textSize=15f }
                feedbackBar.addView(good,LinearLayout.LayoutParams(0,dp(44),1f))
                feedbackBar.addView(bad,LinearLayout.LayoutParams(0,dp(44),1f))
                good.setOnClickListener { rate(turn.id,1) }
                bad.setOnClickListener { rate(turn.id,-1) }
                card.addView(title(if(turn.feedback==0) "Visszajelzés még nincs" else if(turn.feedback>0) "Hasznos válasz" else "Javítandó válasz",11f,SUB))
            }
            panel.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})
        }
        if (busy) panel.addView(title("Az Elizabeth helyi modell válaszol…",14f,HIGHLIGHT,true))
        val field = edit(panel,"Írj kérdést vagy kódolási feladatot…",multiline=true)
        val send = action(panel,"Üzenet küldése") {
            val text = field.text.toString().trim()
            if (text.isEmpty() || busy) return@action
            if (text.length > 3000) { info("Maximum 3000 karakter üzenetenként");return@action }
            data.history.add(ChatTurn(role="user",text=text))
            while(data.history.size > 250) data.history.removeAt(0)
            save()
            busy = true
            val snapshot = ElizabethState.fromJson(data.toJson())
            showApp("chat")
            worker.execute {
                val result = try {
                    if (modelFile().isFile) council.generate(modelFile(),text,snapshot)
                    else rules.noModelReply(text,snapshot)
                } catch (t: Throwable) { "A neurális modell nem indult: ${t.message}. Ellenőrizd a .litertlm modell kompatibilitását." }
                runOnUiThread {
                    if (!stopped.get()) {
                        data.history.add(ChatTurn(role="assistant",text=result.take(12000)))
                        data.log("AI-válasz létrehozva (${if(modelFile().isFile) "modell" else "offline fallback"})")
                        busy = false
                        save()
                        if (unlocked && currentTab == "chat") showApp("chat")
                    }
                }
            }
        }
        send.isEnabled = !busy
        if (!installed) action(panel,"Modell importálása") { requireOwnerPin("Modell importálása") { openModelPicker() } }
    }

    /** Explicit good/bad feedback updates memory retrieval, not neural weights. */
    private fun rate(turnId: String, value: Int) {
        val turn = data.history.firstOrNull{it.id==turnId} ?: return
        if (turn.feedback == value) { info("Már értékelted ezt a választ.");return }
        val record = data.memories.firstOrNull{it.source=="feedback:$turnId"}
        if (record==null && data.memories.size < 400) {
            data.memories.add(Knowledge(
                text=("Kérdés: " + (data.history.takeWhile{it.id!=turnId}.lastOrNull{it.role=="user"}?.text ?: "") +
                    "\nKorábbi válasz: " + turn.text).take(1300),source="feedback:$turnId",
                good=if(value==1) 1 else 0,bad=if(value==-1) 1 else 0))
        } else if (record!=null) {
            if (turn.feedback==1) record.good=(record.good-1).coerceAtLeast(0)
            if (turn.feedback==-1) record.bad=(record.bad-1).coerceAtLeast(0)
            if (value==1) record.good++ else record.bad++
        }
        turn.feedback=value
        data.log("Válasz értékelése: $value")
        save()
        showApp("chat")
    }

    private fun showMemory() {
        panel.addView(title("Személyes, titkosított memória",17f,TEXT,true))
        panel.addView(title("A hozzáadott információkat a relevancia és a korábbi visszajelzések alapján választom ki. A neurális modell súlyait nem tanítom újra.",13f,SUB))
        val input=edit(panel,"Mit jegyezzek meg?",multiline=true)
        action(panel,"Memóriába mentés") {
            val text=input.text.toString().trim()
            if(text.isEmpty() || text.length>3000) { info("1–3000 karakter szükséges");return@action }
            if (data.memories.size>=400) { info("Memórialimit elérve");return@action }
            data.memories.add(Knowledge(text=text))
            data.log("Memória hozzáadva")
            save();showApp("memory")
        }
        panel.addView(title("Mentett emlékek (${data.memories.size})",14f,HIGHLIGHT,true))
        data.memories.takeLast(60).reversed().forEach { m ->
            val card=column().apply { setPadding(dp(9),dp(7),dp(9),dp(7));setBackgroundColor(CARD) }
            card.addView(title(m.text,14f))
            card.addView(title("Forrás: ${m.source.take(50)} | pozitív ${m.good} / negatív ${m.bad}",11f,SUB))
            action(card,"Törlés (PIN)") {
                requireOwnerPin("Memória végleges törlése") {
                    data.memories.removeAll{it.id==m.id}
                    data.log("Memória törölve")
                    save();showApp("memory")
                }
            }
            panel.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(10) })
        }
    }

    private fun showTasks() {
        panel.addView(title("Helyi feladatlista",17f,TEXT,true))
        panel.addView(title("Kézzel irányítható teendők. Az app nem intézkedik rejtve és nem hajt végre külső műveletet.",13f,SUB))
        val input=edit(panel,"Új feladat…")
        action(panel,"Hozzáadás") {
            val txt=input.text.toString().trim()
            if(txt.isEmpty() || txt.length>1000) return@action
            if(data.tasks.size>=400) {info("Feladatlimit elérve");return@action}
            data.tasks.add(Todo(title=txt)); data.log("Helyi feladat létrehozva")
            save();showApp("tasks")
        }
        data.tasks.asReversed().forEach{task ->
            val card=column().apply {setPadding(dp(8),dp(6),dp(8),dp(6));setBackgroundColor(CARD)}
            card.addView(title("${if(task.done) "☑" else "□"} ${task.title}",15f))
            action(card,if(task.done) "Újranyitás" else "Késznek jelölés") {
                task.done=!task.done; save();showApp("tasks")
            }
            action(card,"Törlés (PIN)") {
                requireOwnerPin("Feladat törlése") {
                    data.tasks.removeAll{it.id==task.id}; data.log("Feladat törölve")
                    save();showApp("tasks")
                }
            }
            panel.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)})
        }
    }

    private fun showOwner() {
        panel.addView(title("Tulajdonosi vezérlés",17f,TEXT,true))
        panel.addView(title("Csak Android • teljesen helyi adatkezelés • nincs INTERNET engedély",13f,SUB))
        space(panel)
        panel.addView(title("AI gondolkodási mód",15f,HIGHLIGHT,true))
        val modeNames=listOf("Általános", "Fejlesztő", "Elemző", "Többszereplős tanácskozás (lassú)")
        val modeIds=listOf("GENERAL","DEVELOPER","ANALYST","COUNCIL")
        val spinner=Spinner(this)
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,modeNames)
        spinner.setSelection(modeIds.indexOf(data.aiMode).coerceAtLeast(0))
        panel.addView(spinner,LinearLayout.LayoutParams(-1,dp(52)))
        action(panel,"AI mód alkalmazása") {
            data.aiMode=modeIds[spinner.selectedItemPosition]
            data.log("AI mód: ${data.aiMode}")
            save();showApp("owner")
        }
        space(panel)
        panel.addView(title("Neurális AI-motor",15f,HIGHLIGHT,true))
        panel.addView(title(if(modelFile().isFile) "Telepített fájl: ${modelFile().length() / (1024*1024)} MB (${data.modelName})" else "Nincs importált modell.",13f))
        action(panel,"Kompatibilis .litertlm modell importálása (PIN)") {
            requireOwnerPin("Helyi modell telepítése") { openModelPicker() }
        }
        panel.addView(title("A modell kiválasztása az Android fájlválasztójával történik. A több gigabájtos modelleknek szabad tárhely kell. A betöltés telefonfüggő.",12f,SUB))
        space(panel)
        panel.addView(title("Elizabeth személyisége",15f,HIGHLIGHT,true))
        val name=edit(panel,"Elizabeth megjelenített neve")
        name.setText(data.displayName)
        val language=edit(panel,"Elsődleges nyelv")
        language.setText(data.ownerPreferredLanguage)
        action(panel,"Beállítások helyi mentése") {
            if(name.text.isNotBlank()) data.displayName=name.text.toString().take(100)
            if(language.text.isNotBlank()) data.ownerPreferredLanguage=language.text.toString().take(30)
            data.log("Megjelenítési beállítások módosítva")
            save();showApp("owner")
        }
        space(panel)
        panel.addView(title("Tulajdonosi adatkezelés",15f,HIGHLIGHT,true))
        action(panel,"Titkosított offline biztonsági mentés (PIN)") {
            requireOwnerPin("Titkosított mentés exportálása") { pin ->
                exportPin=pin
                val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type="application/octet-stream"
                    putExtra(Intent.EXTRA_TITLE,"elizabeth-backup.eab")
                }
                startActivityForResult(intent,EXPORT_BACKUP)
            }
        }
        action(panel,"Titkosított mentés visszaállítása (PIN)") {
            requireOwnerPin("Adatok visszaállítása mentésből") { pin ->
                importPin=pin
                val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type="*/*"
                }
                startActivityForResult(intent,IMPORT_BACKUP)
            }
        }
        action(panel,"Beszélgetési előzmények törlése (PIN)") {
            requireOwnerPin("Beszélgetés végleges törlése") {
                data.history.clear();data.log("Beszélgetés törölve")
                save();showApp("owner")
            }
        }
        space(panel)
        panel.addView(title("Képességek és korlátok",15f,HIGHLIGHT,true))
        panel.addView(title("Működik: neurális offline chat betöltött modell esetén, helyi memória, relevanciakeresés, jó/rossz visszajelzés, matematikai fallback, feladatok, AES-GCM, PIN, backup.\n\nNem működik: korlátlan önfejlesztés, modell-súlyok újratanítása, külső alkalmazások irányítása, PC-fájlhozzáférés, felhőszinkron, automatikus internetes kutatás, garantált állandó háttérfutás.",13f,SUB))
        space(panel)
        panel.addView(title("Műveleti napló (utolsó 10)",14f,HIGHLIGHT,true))
        data.audit.takeLast(10).reversed().forEach{panel.addView(title(it,11f,SUB))}
        space(panel,20)
        action(panel,"TULAJDONOSI TELJES HELYI LEÁLLÍTÁS (PIN)") {
            requireOwnerPin("Elizabeth helyi folyamatának leállítása") {
                AlertDialog.Builder(this).setTitle("Elizabeth leállítása?")
                    .setMessage("Az alkalmazás folyamata leáll. Újraindításkor tulajdonosi feloldás kell. Más alkalmazások és a távoli automatizmusok ettől nem állnak le.")
                    .setNegativeButton("Mégse",null)
                    .setPositiveButton("Teljes helyi leállítás") { _, _ ->
                        data.log("Tulajdonos helyi leállítást indított")
                        save()
                        secure.setHalted(true)
                        stopped.set(true)
                        worker.shutdownNow()
                        finishAffinity()
                        Process.killProcess(Process.myPid())
                    }.show()
            }
        }
    }

    private fun requireOwnerPin(reason: String, continuation: (String) -> Unit) {
        val pin = EditText(this).apply { hint="Tulajdonosi PIN"; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle(reason).setView(pin)
            .setNegativeButton("Mégse",null)
            .setPositiveButton("Jóváhagyás") { _, _ ->
                val p=pin.text.toString()
                if (secure.verifyPin(p)) continuation(p) else info("Jóváhagyás elutasítva: hibás PIN")
            }.show()
    }

    private fun openModelPicker() {
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type="*/*"
        }
        startActivityForResult(intent,PICK_MODEL)
    }

    override fun onActivityResult(requestCode: Int,resultCode: Int,resultData: Intent?) {
        super.onActivityResult(requestCode,resultCode,resultData)
        if (!unlocked) { exportPin="";importPin="";return }
        if (resultCode!=RESULT_OK || resultData?.data==null) {
            exportPin="";importPin="";return
        }
        val uri = resultData.data!!
        when(requestCode) {
            PICK_MODEL -> importModel(uri)
            EXPORT_BACKUP -> {
                try {
                    val text=secure.encryptedBackup(data,exportPin)
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(StandardCharsets.UTF_8)) }
                        ?: error("Nem nyitható export cél")
                    data.log("Titkosított backup export")
                    save();info("Titkosított mentés elkészült")
                } catch (e:Exception) {info("Mentési hiba: ${e.message}")}
                finally {exportPin=""}
            }
            IMPORT_BACKUP -> {
                try {
                    val backup=contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                        // Bound content size even if source URI lies about its length.
                        val result=StringBuilder()
                        val chars=CharArray(8192)
                        while(true) {
                            val count=reader.read(chars)
                            if(count<0) break
                            result.append(chars,0,count)
                            if(result.length>12_000_000) error("Túl nagy mentés")
                        }
                        result.toString()
                    } ?: error("Nem olvasható fájl")
                    val parsed=secure.readBackup(backup,importPin)
                    AlertDialog.Builder(this).setTitle("Adatok visszaállítása?")
                        .setMessage("A jelenlegi beszélgetést, memóriát és feladatokat felülírja. A modellt nem cseréli le.")
                        .setNegativeButton("Mégse",null)
                        .setPositiveButton("Visszaállítás") { _, _ ->
                            val previousName=data.modelName
                            data=parsed
                            data.modelName=previousName
                            data.log("Titkosított backup visszaállítva")
                            save();showApp("owner")
                        }.show()
                } catch(e:Exception) { info("Hibás vagy sérült mentés: ${e.message}") }
                finally{importPin=""}
            }
        }
    }

    private fun importModel(uri: Uri) {
        if (busy) {info("AI-válasz közben modell nem cserélhető");return}
        val display = try {
            contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{cursor->
                if(cursor.moveToFirst()) cursor.getString(0) else ""
            } ?: ""
        } catch (_:Exception){ "" }
        if (!display.lowercase().endsWith(".litertlm")) {
            info("Csak LiteRT-LM kompatibilis .litertlm modell választható.");return
        }
        busy=true
        showApp("owner")
        panel.addView(title("Modell másolása az alkalmazásba…",14f,HIGHLIGHT))
        worker.execute {
            val dest=modelFile()
            val tmp=File(filesDir,"models/import.part")
            try {
                dest.parentFile!!.mkdirs()
                contentResolver.openInputStream(uri)?.use { input ->
                    tmp.outputStream().use { out ->
                        val buf=ByteArray(256*1024)
                        var total=0L
                        while(true) {
                            val n=input.read(buf)
                            if(n<0) break
                            total+=n
                            require(total <= 10L*1024*1024*1024) { "Max. 10 GB modell" }
                            out.write(buf,0,n)
                        }
                    }
                } ?: error("A modell nem olvasható")
                require(tmp.length() > 1024) { "Üres vagy sérült modell" }
                neural.close()
                if(dest.exists()) require(dest.delete())
                check(tmp.renameTo(dest)) { "Nem sikerült áthelyezni a modellfájlt" }
                runOnUiThread {
                    if (!stopped.get()) {
                        data.modelName=display.take(150)
                        data.log("Offline neurális modell importálva")
                        save();info("Modell helyben másolva. A következő üzenetkor indul.")
                        busy=false;showApp("owner")
                    }
                }
            } catch(e:Exception) {
                tmp.delete()
                runOnUiThread{ if(!stopped.get()) { busy=false;info("Modell import hiba: ${e.message}");showApp("owner") } }
            }
        }
    }

    private fun info(text: String) { Toast.makeText(this,text,Toast.LENGTH_LONG).show() }

    override fun onStop() {
        lastBackgroundAt = System.currentTimeMillis()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (::secure.isInitialized && unlocked && lastBackgroundAt > 0L &&
            System.currentTimeMillis() - lastBackgroundAt > 120_000L) {
            unlocked=false
            exportPin=""
            importPin=""
            showUnlock()
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        // Avoid racing with an ongoing native inference. The process owns native memory lifetime.
        super.onDestroy()
    }
}
