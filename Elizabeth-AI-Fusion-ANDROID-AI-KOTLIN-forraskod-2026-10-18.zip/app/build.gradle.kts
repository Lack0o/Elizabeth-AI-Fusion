plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "hu.elizabeth.fusion"
    compileSdk = 35
    defaultConfig {
        applicationId = "hu.elizabeth.fusion"
        minSdk = 28
        targetSdk = 35
        versionCode = 2
        versionName = "1.0.0-alpha"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    // Official offline, on-device neural LLM runtime. The model itself is imported by the owner.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")
    testImplementation("junit:junit:4.13.2")
}

kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }
