package hu.elizabeth.aifusion;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int EXPORT_CSV = 601;
    private static final String[] LOCATIONS = {"WH1 / 1", "WH1 / 2", "WH1 / 3", "WH1 / 4", "WH2 / 1", "WH2 / 2", "WH2 / 3", "WH3 / 1", "WH3 / 2", "WH3 / 3"};
    private static final int BG = Color.rgb(17,25,36), PANEL = Color.rgb(34,47,64);
    private static final int WHITE = Color.rgb(245,248,252), MUTED = Color.rgb(181,192,209), ACCENT = Color.rgb(98,185,232);
    private SharedPreferences storage;
    private LinearLayout page;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        storage = getSharedPreferences("elizabeth_local_v1", MODE_PRIVATE);
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(18), dp(14), dp(8));
        setContentView(root);
        root.addView(text("Nagy Noémi Elizabeth", 23, WHITE, true));
        root.addView(text("AI Fusion • Android offline alapverzió", 12, MUTED, false));
        gap(root, 12);
        LinearLayout menu = new LinearLayout(this);
        root.addView(menu);
        tab(menu, "Kezdőlap", () -> home());
        tab(menu, "Segéd", () -> assistant());
        tab(menu, "Készlet", () -> inventory());
        tab(menu, "Jegyzet", () -> notes());
        ScrollView scroller = new ScrollView(this);
        root.addView(scroller, new LinearLayout.LayoutParams(-1, 0, 1));
        page = column();
        page.setPadding(0, dp(10), 0, dp(24));
        scroller.addView(page);
        home();
    }

    private LinearLayout column() { LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); return c; }
    private int dp(int d) { return Math.round(getResources().getDisplayMetrics().density*d); }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0,dp(5),0,dp(5)); return t;
    }
    private void gap(LinearLayout target, int height) { target.addView(new View(this), new LinearLayout.LayoutParams(1,dp(height))); }
    private EditText field(String hint) {
        EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(MUTED); e.setTextColor(WHITE);
        e.setTextSize(16); e.setSingleLine(true); e.setBackgroundColor(PANEL);
        e.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(9); e.setLayoutParams(p);
        return e;
    }
    private void button(LinearLayout target, String label, Runnable job) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false);
        target.addView(b,new LinearLayout.LayoutParams(-1,-2)); b.setOnClickListener(v->job.run());
    }
    private void tab(LinearLayout target, String label, Runnable job) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(11);
        target.addView(b,new LinearLayout.LayoutParams(0,dp(48),1)); b.setOnClickListener(v->job.run());
    }
    private void header(String title, String desc) {
        page.removeAllViews(); page.addView(text(title,20,WHITE,true)); page.addView(text(desc,13,MUTED,false)); gap(page,10);
    }
    private void home() {
        header("Offline munkafelület", "Az alkalmazás nem kér internet-hozzáférést.");
        page.addView(text("MŰKÖDŐ FUNKCIÓK",14,ACCENT,true));
        page.addView(text("• Helyi jegyzetek és beszélgetési előzmények\n• Korlátozott, szabályalapú SDS/ADR/ATEX segéd\n• Készletnyilvántartás 10 alhelyen\n• 20%-os készletfigyelés a megadott célkészlethez\n• CSV exportálás",15,WHITE,false));
        gap(page,12);
        page.addView(text("NEM TELJES MESTERSÉGES INTELLIGENCIA",14,ACCENT,true));
        page.addView(text("A v0.1 nem tartalmaz helyben futó nyelvi modellt, SDS PDF-elemzést, kamerás felismerést vagy hitelesített anyag-összeférhetőségi döntést. Veszélyes anyag tárolásához mindig ellenőrzött SDS és EHS-jóváhagyás szükséges.",14,WHITE,false));
        gap(page,12); button(page,"Készlet megnyitása",()->inventory());
    }
    private String answer(String q) {
        String x=q.toLowerCase(Locale.ROOT);
        if(x.contains("sds") || x.contains("adatlap")) return "Az aktuális SDS 2., 7., 9., 10. és 14. szakaszát ellenőrizni kell. A demonstráció nem dolgoz fel PDF-et és nem hagy jóvá tárolást.";
        if(x.contains("adr") || x.contains("un ")) return "ADR-besorolás az adott anyag és érvényes SDS 14. szakasza, valamint a hatályos ADR alapján végezhető; önmagában az UN-szám nem elég.";
        if(x.contains("atex") || x.contains("robban")) return "ATEX-zóna csak dokumentált robbanásvédelmi értékelés alapján adható meg. Itt nincs automatikus ATEX-besorolás.";
        if(x.contains("raktár") || x.contains("készlet")) return "A Készlet fülön a hely, termék, mennyiség és célkészlet menthető; a 20% alatti készlet jelzést kap.";
        return "A jelenlegi Elizabeth offline, szabályalapú demó. Nincs benne általános AI-modell. Kérdezhetsz SDS/ADR/ATEX vagy készlet témában.";
    }
    private void assistant() {
        header("Offline segéd", "Szabályalapú válaszok. Nem teljes ChatGPT/LLM.");
        TextView history=text(storage.getString("history","Elizabeth: Szia! SDS, ADR, ATEX és készlet témában tudok korlátozott segítséget adni."),14,WHITE,false);
        history.setTextIsSelectable(true); page.addView(history); gap(page,12);
        EditText question=field("Írd ide az üzenetet..."); page.addView(question);
        button(page,"Küldés",()->{
            String q=question.getText().toString().trim(); if(q.isEmpty())return;
            String old=storage.getString("history","");
            String result=old+"\n\nTe: "+q+"\nElizabeth: "+answer(q);
            if(result.length()>14000)result=result.substring(result.length()-14000);
            storage.edit().putString("history",result).apply(); history.setText(result); question.setText("");
        });
        button(page,"Előzmény törlése",()->new AlertDialog.Builder(this).setMessage("Biztosan törlöd?")
            .setNegativeButton("Mégse",null).setPositiveButton("Törlés",(d,w)->{storage.edit().remove("history").apply();assistant();}).show());
    }
    private void notes() {
        header("Jegyzetek", "Az adatok a telefon alkalmazástárában vannak tárolva.");
        EditText entry=field("Jegyzet..."); entry.setSingleLine(false); entry.setMinLines(10);
        entry.setText(storage.getString("note","")); page.addView(entry);
        button(page,"Mentés",()->{storage.edit().putString("note",entry.getText().toString()).apply();Toast.makeText(this,"Elmentve",Toast.LENGTH_SHORT).show();});
    }
    private JSONArray records() { try { return new JSONArray(storage.getString("stock","[]")); } catch(Exception e) {return new JSONArray();} }
    private void inventory() {
        header("Raktári készlet", "Csak adminisztratív nyilvántartás, nem tárolási engedély.");
        EditText product=field("Termék / anyag neve"); page.addView(product);
        Spinner spot=new Spinner(this); spot.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,LOCATIONS));
        page.addView(spot,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText count=field("Mennyiség (szám)"); count.setInputType(8194); page.addView(count);
        EditText target=field("Célkészlet (opcionális)"); target.setInputType(8194); page.addView(target);
        button(page,"Tétel mentése",()->{
            String name=product.getText().toString().trim(); double current,goal=0;
            try {
                current=Double.parseDouble(count.getText().toString().replace(',','.'));
                if(!target.getText().toString().trim().isEmpty())goal=Double.parseDouble(target.getText().toString().replace(',','.'));
                if(!Double.isFinite(current)||!Double.isFinite(goal)||current<0||goal<0)throw new NumberFormatException();
            } catch(NumberFormatException ex) {Toast.makeText(this,"Nem megfelelő mennyiség",Toast.LENGTH_LONG).show();return;}
            if(name.isEmpty()){Toast.makeText(this,"Adj meg egy nevet",Toast.LENGTH_SHORT).show();return;}
            try {
                JSONObject item=new JSONObject(); item.put("name",name); item.put("place",String.valueOf(spot.getSelectedItem()));
                item.put("amount",current); item.put("target",goal);
                JSONArray all=records(); all.put(item); storage.edit().putString("stock",all.toString()).apply();inventory();
            } catch(Exception e) {Toast.makeText(this,"Mentési hiba",Toast.LENGTH_SHORT).show();}
        });
        button(page,"CSV exportálás",()->{
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("text/csv"); i.putExtra(Intent.EXTRA_TITLE,"Elizabeth_keszlet.csv"); startActivityForResult(i,EXPORT_CSV);
        });
        gap(page,12);
        JSONArray all=records(); page.addView(text("MENTETT TÉTELEK: "+all.length(),14,ACCENT,true));
        for(int n=all.length()-1;n>=0;n--){
            final int index=n; JSONObject item=all.optJSONObject(n); if(item==null)continue;
            double a=item.optDouble("amount",0), t=item.optDouble("target",0); boolean low=t>0&&a<.2*t;
            TextView row=text(item.optString("name")+"\n"+item.optString("place")+"   "+a+(t>0?" / "+t:"")+(low?"\nALACSONY KÉSZLET (<20%)":"")+"\nHosszan nyomva törölhető",14,low?Color.rgb(255,184,116):WHITE,false);
            row.setPadding(dp(10),dp(10),dp(10),dp(10)); row.setBackgroundColor(PANEL);page.addView(row);gap(page,7);
            row.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("Törlöd a tételt?")
                .setNegativeButton("Mégse",null).setPositiveButton("Törlés",(d,w)->{
                    JSONArray old=records(), changed=new JSONArray();for(int j=0;j<old.length();j++)if(j!=index)changed.put(old.opt(j));
                    storage.edit().putString("stock",changed.toString()).apply();inventory();
                }).show();return true;});
        }
        gap(page,8);page.addView(text("Valós tárolási megfelelőség kizárólag szakmai SDS/ADR/ATEX/EHS-vizsgálattal dönthető el.",13,MUTED,false));
    }
    private String csv(String s) {return "\""+s.replace("\"","\"\"")+"\"";}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=EXPORT_CSV||result!=RESULT_OK||data==null)return;
        Uri uri=data.getData();if(uri==null)return;
        StringBuilder sb=new StringBuilder("Megnevezes;Raktar;Mennyiseg;Celkészlet;Figyelmeztetes\n");
        JSONArray all=records();for(int i=0;i<all.length();i++){
            JSONObject o=all.optJSONObject(i);if(o==null)continue;
            double a=o.optDouble("amount",0),t=o.optDouble("target",0);
            sb.append(csv(o.optString("name"))).append(';').append(csv(o.optString("place"))).append(';')
                .append(a).append(';').append(t).append(';').append(t>0&&a<.2*t?"IGEN":"NEM").append('\n');
        }
        try(OutputStream os=getContentResolver().openOutputStream(uri)){
            if(os==null)throw new Exception("No output stream");
            os.write(("\uFEFF"+sb).getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this,"CSV elkészült",Toast.LENGTH_SHORT).show();
        }catch(Exception e){Toast.makeText(this,"Exportálási hiba",Toast.LENGTH_LONG).show();}
    }
}
