# Nagy Noémi Elizabeth – Android prototype

This is a **minimal Android prototype**, not the complete AI Fusion system. It currently stores offline notes on the device. It does not contain an AI model, SDS/ATEX decision engine, cloud access or background agent.

## Build
Upload the contents of this ZIP to the repository root, preserving directories. In GitHub open Actions → Build Android APK → Run workflow. Download the debug APK from the completed run's Artifacts section. Android debug builds are for testing, not production distribution.

Uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17 and Gradle 8.9. Build not verified in this environment.
