plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "hu.elizabeth.ai"; compileSdk = 35
 defaultConfig { applicationId = "hu.elizabeth.ai"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" } }
