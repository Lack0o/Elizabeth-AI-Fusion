package hu.elizabeth.ai

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.EditText

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val prefs = getSharedPreferences("local", MODE_PRIVATE)
  val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,24) }
  val title = TextView(this).apply { text = "Nagy Noémi Elizabeth"; textSize = 26f }
  val status = TextView(this).apply { text = "Offline jegyzetek – első működő prototípus"; textSize = 16f }
  val notes = EditText(this).apply { hint = "Írj egy jegyzetet"; setText(prefs.getString("notes", "")); minLines = 5 }
  val save = Button(this).apply { text = "Mentés a telefonra"; setOnClickListener { prefs.edit().putString("notes", notes.text.toString()).apply(); status.text = "Helyben elmentve" } }
  layout.addView(title); layout.addView(status); layout.addView(notes); layout.addView(save)
  setContentView(layout)
 }
}
